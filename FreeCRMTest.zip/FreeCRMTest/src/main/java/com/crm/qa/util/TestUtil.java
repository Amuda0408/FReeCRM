package com.crm.qa.util;

public class TestUtil {
	public static long PAGE_LOAD_TIMEOUT =30;
	public static long IMPLICIT_WAIT =20;
	
}
